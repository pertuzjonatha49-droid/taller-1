import subprocess
import sys
from pathlib import Path

base = Path(__file__).parent
carpetas = ["ejemplos", "ejercicios_resueltos", "ejercicios_propuestos"]

for carpeta in carpetas:
    for archivo in sorted((base / carpeta).glob("*.py")):
        print(f"\n===== {carpeta}/{archivo.name} =====")
        subprocess.run([sys.executable, str(archivo)])
