class NotificadorEmail:
    def enviar(self, mensaje: str):
        print(f"Enviando Email: {mensaje}")


class NotificadorSMS:
    def enviar(self, mensaje: str):
        print(f"Enviando SMS: {mensaje}")


def notificar_alerta(notificador, texto):
    notificador.enviar(texto)


notificar_alerta(NotificadorEmail(), "Fallo en servidor DB")
notificar_alerta(NotificadorSMS(), "Fallo en servidor DB")
