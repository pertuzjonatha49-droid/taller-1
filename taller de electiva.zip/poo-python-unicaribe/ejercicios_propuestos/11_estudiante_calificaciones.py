class Estudiante:
    def __init__(self, nombre: str):
        self.__nombre = nombre
        self.__notas = []

    @property
    def nombre(self) -> str:
        return self.__nombre

    @property
    def notas(self) -> list:
        return self.__notas.copy()  # copia: no se modifica desde afuera

    def agregar_nota(self, nota: float):
        if 0.0 <= nota <= 5.0:
            self.__notas.append(nota)
        else:
            print(f"Error: la nota {nota} debe estar entre 0.0 y 5.0")

    def calcular_promedio(self) -> float:
        if not self.__notas:
            return 0.0
        return sum(self.__notas) / len(self.__notas)


est = Estudiante("Ana")
est.agregar_nota(4.5)
est.agregar_nota(3.8)
est.agregar_nota(5.5)  # Error
est.agregar_nota(-1)   # Error
print(est.nombre)
print(est.notas)
print(f"Promedio: {est.calcular_promedio():.2f}")  # 4.15

est.notas.append(5.0)  # solo modifica la copia
print(est.notas)       # sigue igual
