class TarjetaCredito:
    def __init__(self, titular: str):
        self.titular = titular

    def calcular_cashback(self, monto: float) -> float:
        return 0.0


class TarjetaGold(TarjetaCredito):
    def calcular_cashback(self, monto: float) -> float:
        return monto * 0.02


class TarjetaBlack(TarjetaCredito):
    def calcular_cashback(self, monto: float) -> float:
        return monto * 0.05


tarjetas = [
    TarjetaCredito("Luis"),
    TarjetaGold("Ana"),
    TarjetaBlack("Carlos"),
]

compra = 1000.0
for t in tarjetas:
    print(f"{t.titular} ({type(t).__name__}): cashback ${t.calcular_cashback(compra):.2f}")
