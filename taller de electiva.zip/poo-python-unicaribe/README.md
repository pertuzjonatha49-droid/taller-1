# POO en Python — Unidad 3 (Unicaribe)

Ejemplos y ejercicios de la guía *Programación Orientada a Objetos en Python*
(Facultad de Ingeniería, Ing. Neider Hernández, 2026).

## Estructura

| Carpeta | Contenido |
|---|---|
| `ejemplos/` | Códigos 01–08 de los temas: clases, herencia, polimorfismo y encapsulación |
| `ejercicios_resueltos/` | Códigos 09–10, ejercicios resueltos de la guía |
| `ejercicios_propuestos/` | Códigos 11–12, ejercicios propuestos con solución |

## Cómo ejecutar

Requiere Python 3.9 o superior.

```bash
python ejemplos/01_clases_objetos.py
python ejercicios_propuestos/12_tarjetas_credito.py
```

Para correr todos:

```bash
python ejecutar_todos.py
```
