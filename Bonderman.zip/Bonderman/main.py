import os
import sys
import random
import pygame
from mapas import NIVELES

BASE = os.path.dirname(os.path.abspath(__file__))

TAM = 40
COLS, FILAS = 15, 11
ANCHO, ALTO = COLS * TAM, FILAS * TAM + 30
MECHA = 2500      # ms que tarda la bomba en explotar
LLAMA = 700       # ms que dura el fuego
RADIO = 3         # alcance de la explosion en casillas
MAX_BOMBAS = 2
VIDAS = 3

pygame.init()
try:
    pygame.mixer.init()
    HAY_AUDIO = True
except pygame.error:
    HAY_AUDIO = False

# SCALED permite pantalla completa (F11) escalando el juego sin deformarlo
pantalla = pygame.display.set_mode((ANCHO, ALTO), pygame.SCALED)
pygame.display.set_caption("Bomberman")
reloj = pygame.time.Clock()
fuente = pygame.font.SysFont(None, 28)
grande = pygame.font.SysFont(None, 60)
chica = pygame.font.SysFont(None, 24)


# ---------- Imagenes y sonidos (si el archivo no existe, usa dibujos/silencio) ----------
def img(nombre):
    ruta = os.path.join(BASE, "imagenes", nombre)
    if os.path.exists(ruta):
        return pygame.transform.scale(pygame.image.load(ruta).convert_alpha(), (TAM, TAM))
    return None


def cargar_sonido(nombre):
    ruta = os.path.join(BASE, "sonidos", nombre)
    if HAY_AUDIO and os.path.exists(ruta):
        return pygame.mixer.Sound(ruta)
    return None


def tocar(sonido):
    if sonido:
        sonido.play()


IMG_JUGADOR = img("jugador.png")
IMG_ENEMIGO = img("enemigo.png")
IMG_MURO = img("muro.png")
IMG_BLOQUE = img("bloque.png")
IMG_PISO = img("piso.png")
IMG_BOMBA = img("bomba.png")
IMG_FUEGO = img("fuego.png")

SND_EXPLOSION = cargar_sonido("explosion.wav")
SND_PONER = cargar_sonido("poner.wav")
SND_MUERTE = cargar_sonido("muerte.wav")

if HAY_AUDIO:
    for nombre in ("musica.ogg", "musica.mp3", "musica.wav"):
        ruta = os.path.join(BASE, "sonidos", nombre)
        if os.path.exists(ruta):
            pygame.mixer.music.load(ruta)
            pygame.mixer.music.set_volume(0.4)
            pygame.mixer.music.play(-1)
            break


def dibujar(imagen, c, f, color, margen=0):
    if imagen:
        pantalla.blit(imagen, (c * TAM, f * TAM))
    else:
        pygame.draw.rect(pantalla, color,
                         (c * TAM + margen, f * TAM + margen, TAM - 2 * margen, TAM - 2 * margen))


# ---------- Estado del juego ----------
grid = []
jugador = [1, 1]
enemigos = []
bombas = []
llamas = []
nivel = 0
vidas = VIDAS
puntos = 0
estado = "jugando"
ultimo_mov = 0
ultimo_enemigo = 0
ayuda = True          # la ayuda se muestra al empezar
inicio_pausa = 0


def cargar(n):
    global grid, jugador, enemigos, bombas, llamas
    grid = [list(fila) for fila in NIVELES[n]]
    enemigos = []
    bombas = []
    llamas = []
    for f in range(FILAS):
        for c in range(COLS):
            if grid[f][c] == "P":
                jugador = [c, f]
                grid[f][c] = "."
            elif grid[f][c] == "E":
                enemigos.append([c, f])
                grid[f][c] = "."


def reiniciar_todo():
    global nivel, vidas, puntos, estado
    nivel = 0
    vidas = VIDAS
    puntos = 0
    estado = "jugando"
    cargar(0)


def hay_bomba(c, f):
    return any(b["c"] == c and b["f"] == f for b in bombas)


def libre(c, f):
    return 0 <= c < COLS and 0 <= f < FILAS and grid[f][c] == "." and not hay_bomba(c, f)


def explotar(b, ahora):
    celdas = {(b["c"], b["f"])}
    for dc, df in ((1, 0), (-1, 0), (0, 1), (0, -1)):
        for i in range(1, RADIO + 1):
            c = b["c"] + dc * i
            f = b["f"] + df * i
            if grid[f][c] == "#":
                break
            celdas.add((c, f))
            if grid[f][c] == "+":
                grid[f][c] = "."
                break
    llamas.append({"celdas": celdas, "t": ahora})
    bombas.remove(b)
    tocar(SND_EXPLOSION)


def morir():
    global vidas, estado
    tocar(SND_MUERTE)
    vidas -= 1
    if vidas <= 0:
        estado = "perdiste"
    else:
        cargar(nivel)


reiniciar_todo()

while True:
    ahora = pygame.time.get_ticks()

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if e.type == pygame.KEYDOWN:
            if e.key in (pygame.K_h, pygame.K_F1) or (e.key == pygame.K_ESCAPE and ayuda):
                if ayuda:
                    ayuda = False
                    pausa = ahora - inicio_pausa   # la bomba no avanza mientras ves la ayuda
                    for b in bombas:
                        b["t"] += pausa
                    for l in llamas:
                        l["t"] += pausa
                else:
                    ayuda = True
                    inicio_pausa = ahora
            if e.key in (pygame.K_F11, pygame.K_f):
                pygame.display.toggle_fullscreen()   # pantalla completa / ventana
            if e.key in (pygame.K_SPACE, pygame.K_b, pygame.K_RETURN) and estado == "jugando" and not ayuda:
                if not hay_bomba(jugador[0], jugador[1]) and len(bombas) < MAX_BOMBAS:
                    bombas.append({"c": jugador[0], "f": jugador[1], "t": ahora})
                    tocar(SND_PONER)
            if e.key == pygame.K_r and estado != "jugando":
                reiniciar_todo()

    if estado == "jugando" and not ayuda:
        # Movimiento del jugador (una casilla cada 130 ms)
        teclas = pygame.key.get_pressed()
        if ahora - ultimo_mov > 130:
            dc = (teclas[pygame.K_RIGHT] or teclas[pygame.K_d]) - (teclas[pygame.K_LEFT] or teclas[pygame.K_a])
            df = (teclas[pygame.K_DOWN] or teclas[pygame.K_s]) - (teclas[pygame.K_UP] or teclas[pygame.K_w])
            if dc != 0:
                df = 0
            if (dc or df) and libre(jugador[0] + dc, jugador[1] + df):
                jugador[0] += dc
                jugador[1] += df
                ultimo_mov = ahora

        # Movimiento de enemigos (una casilla cada 350 ms)
        if ahora - ultimo_enemigo > 350:
            ultimo_enemigo = ahora
            for en in enemigos:
                dirs = [(1, 0), (-1, 0), (0, 1), (0, -1)]
                random.shuffle(dirs)
                for dc, df in dirs:
                    if libre(en[0] + dc, en[1] + df):
                        en[0] += dc
                        en[1] += df
                        break

        # Bombas: explotan por tiempo o por reaccion en cadena
        for b in list(bombas):
            if ahora - b["t"] >= MECHA or any((b["c"], b["f"]) in l["celdas"] for l in llamas):
                explotar(b, ahora)

        # Quitar fuego viejo
        llamas = [l for l in llamas if ahora - l["t"] < LLAMA]
        fuego = set()
        for l in llamas:
            fuego |= l["celdas"]

        # Enemigos alcanzados por el fuego
        vivos = [en for en in enemigos if tuple(en) not in fuego]
        puntos += 100 * (len(enemigos) - len(vivos))
        enemigos = vivos

        # Jugador alcanzado por fuego o tocado por un enemigo
        if tuple(jugador) in fuego or any(en == jugador for en in enemigos):
            morir()
        elif not enemigos:
            nivel += 1
            if nivel >= len(NIVELES):
                estado = "ganaste"
            else:
                cargar(nivel)

    # ---------- Dibujo ----------
    pantalla.fill((30, 120, 50))
    for f in range(FILAS):
        for c in range(COLS):
            if IMG_PISO:
                pantalla.blit(IMG_PISO, (c * TAM, f * TAM))
            if grid[f][c] == "#":
                dibujar(IMG_MURO, c, f, (90, 90, 100))
            elif grid[f][c] == "+":
                dibujar(IMG_BLOQUE, c, f, (160, 110, 60))
    for l in llamas:
        for (c, f) in l["celdas"]:
            dibujar(IMG_FUEGO, c, f, (255, 160, 0), 4)
    for en in enemigos:
        dibujar(IMG_ENEMIGO, en[0], en[1], (210, 30, 30), 6)
    dibujar(IMG_JUGADOR, jugador[0], jugador[1], (240, 240, 255), 6)
    for b in bombas:
        if IMG_BOMBA:
            pantalla.blit(IMG_BOMBA, (b["c"] * TAM, b["f"] * TAM))
        else:
            centro = (b["c"] * TAM + TAM // 2, b["f"] * TAM + TAM // 2)
            color = (255, 0, 0) if (ahora // 200) % 2 == 0 else (0, 0, 0)
            pygame.draw.circle(pantalla, (0, 0, 0), centro, TAM // 2 - 4)
            pygame.draw.circle(pantalla, color, centro, TAM // 6)

    pygame.draw.rect(pantalla, (20, 20, 20), (0, FILAS * TAM, ANCHO, 30))
    hud = chica.render(
        f"Nivel {min(nivel + 1, len(NIVELES))}/{len(NIVELES)}   Vidas: {vidas}   Puntos: {puntos}   H: ayuda   F11: pantalla completa",
        True, (255, 255, 255))
    pantalla.blit(hud, (8, FILAS * TAM + 5))

    if estado != "jugando":
        texto = "¡Ganaste!" if estado == "ganaste" else "Perdiste"
        t = grande.render(texto, True, (255, 255, 255))
        s = fuente.render("Presiona R para reiniciar", True, (255, 255, 0))
        pantalla.blit(t, (ANCHO // 2 - t.get_width() // 2, 180))
        pantalla.blit(s, (ANCHO // 2 - s.get_width() // 2, 250))

    if ayuda:
        velo = pygame.Surface((ANCHO, ALTO))
        velo.set_alpha(225)
        velo.fill((0, 0, 0))
        pantalla.blit(velo, (0, 0))
        titulo = grande.render("AYUDA", True, (255, 220, 0))
        pantalla.blit(titulo, (ANCHO // 2 - titulo.get_width() // 2, 20))
        lineas = [
            "Moverte: flechas o W A S D",
            "Poner bomba: ESPACIO (o B / Enter)",
            "La bomba explota a los 2.5 segundos",
            "El fuego rompe los bloques naranja, no los grises",
            "Aléjate de la bomba o pierdes una vida",
            "Mata a todos los enemigos rojos para pasar de nivel",
            "F11 o F: pantalla completa / ventana",
            "R: reiniciar cuando termina el juego",
            "H o F1: abrir y cerrar esta ayuda",
        ]
        y = 95
        for linea in lineas:
            txt = fuente.render(linea, True, (255, 255, 255))
            pantalla.blit(txt, (ANCHO // 2 - txt.get_width() // 2, y))
            y += 32
        ok = fuente.render("Presiona H o ESC para empezar a jugar", True, (255, 255, 0))
        pantalla.blit(ok, (ANCHO // 2 - ok.get_width() // 2, y + 25))

    pygame.display.flip()
    reloj.tick(60)
